# 일반 문서
```
공통
1. API_SPEC.md
```

```
프론트엔드
1. FRONTEND_DESIGN.md
```

# stack 문서
```
백엔드
1. rest_api.md
2. flask.md
3. open_api_spec.md
```
```
프론트엔드
1. front.md
2. js.md
3. jsdoc.md
```
