# JSDoc
자바스크립트 문서화를 도와주는 도구

참고: [https://jsdoc.app/](https://jsdoc.app/)

소스코드 내에 주석을 특정한 형식에 맞춰서 작성하면, 그걸 쉽게 문서화 시켜줍니다.

제가 짠 api.js, color.js 파일 보면 함수 위에 주석이 달려있을텐데, 그게 JSDoc 형식에 맞춰서 쓴 주석이에요.